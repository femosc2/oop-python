class Person():
    """ time """
    def __init__(self, age):
        self.age = age;
