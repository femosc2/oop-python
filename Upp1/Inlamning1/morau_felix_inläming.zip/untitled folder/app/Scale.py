from Luggage import Luggage

class Scale():
    """ A blueprint for a scale """
    def __init__(self):
        """ Not used """

    def sendWeight(self, weight):
        """ Sends the weight to the controlmachine """
        pass
    def weightLuggage(self, luggage):
        """ Weighs the luggage and returns the weight as an float """
        pass