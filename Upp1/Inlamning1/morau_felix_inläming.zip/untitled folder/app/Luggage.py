class Luggage():
    """ Blueprint for luggage """
    def __init__(self, weight, width, height):
        """ Creates a new Luggage object """
        self.weight = weight
        self.width = width
        self.height = height