from Luggage import Luggage

class BagLabel():
    """ Creates the blueprint for a label """
    def __init__(self, id, destination):
        """ Creates the Label """
        self.id = id
        self.destination = destination