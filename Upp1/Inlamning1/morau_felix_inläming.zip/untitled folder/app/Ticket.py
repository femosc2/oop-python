class Ticket():
    """ Creates a blueprint for Tickets """
    def __init__(self, isValid, id):
        """ Creates a new ticket object """
        self.isValid = isValid
        self.id = id
